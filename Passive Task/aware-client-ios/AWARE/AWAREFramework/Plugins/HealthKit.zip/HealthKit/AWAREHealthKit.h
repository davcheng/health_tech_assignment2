//
//  AWAREHealthKit.h
//  AWARE
//
//  Created by Yuuki Nishiyama on 2/1/16.
//  Copyright © 2016 Yuuki NISHIYAMA. All rights reserved.
//

#import "AWAREPlugin.h"

@interface AWAREHealthKit : AWARESensor <AWARESensorDelegate>

@end
